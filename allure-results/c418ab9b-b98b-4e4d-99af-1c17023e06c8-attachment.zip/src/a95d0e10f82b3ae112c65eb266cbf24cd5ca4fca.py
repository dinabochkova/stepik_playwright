from components.base_component import BaseComponent
from playwright.sync_api import Page, expect
from elements.input import Input
import  allure

class LoginFormComponent(BaseComponent):
    def __init__(self, page: Page):
        super().__init__(page)
        self.email_input = Input(page,'login-form-email-input', 'Email')
        self.password_input = Input(page, 'login-form-password-input', 'Password')

    @allure.step('Fill login form')
    def fill(self, email, password):
        self.email_input.fill(email)
        self.password_input.fill(password)

    @allure.step('Check that login form is visible')
    def check_visible(self, email, password):
        self.email_input.check_visible()
        self.email_input.check_have_value(email)
        self.password_input.check_visible()
        self.password_input.check_have_value(password)

