from playwright.sync_api import Page, expect
from typing import Pattern
import allure

class BaseComponent:
    def __init__(self, page: Page):
        self.page = page

    def check_current_url(self, expected_url: Pattern[str]):
        with allure.step("check current url"):
            expect(self.page).to_have_url(expected_url)